import React from 'react'

function Main() {
  return (
    <div>
      Home Page.. ! 1
    </div>
  )
}

export default Main
