import React from 'react'
import { Link } from 'react-router-dom'
import { auth } from '../config/firebase'

function Navbar() {
  return (
    <div>
      <Link to="/">Home</Link>
      <Link to="/login">Login</Link>

      <p>{auth.currentUser?.displayName}</p>
      <img src={auth.currentUser?.photoURL || ""} width="100" height="100" alt="alt pic.. !  " />

    </div>
  )
}

export default Navbar
