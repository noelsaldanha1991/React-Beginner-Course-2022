// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getAuth, GoogleAuthProvider} from 'firebase/auth'
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDlznZKmLUXQ536ADPkdvdOXZiYHUdG5kE",
  authDomain: "react-course-50633.firebaseapp.com",
  projectId: "react-course-50633",
  storageBucket: "react-course-50633.firebasestorage.app",
  messagingSenderId: "735090847586",
  appId: "1:735090847586:web:5c3713c2e1d53218a5463b"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth =getAuth(app);
export const provider = new GoogleAuthProvider();