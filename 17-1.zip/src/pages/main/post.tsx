import React, { useState, useEffect } from 'react';
import { Post as IPost } from "./main";

import {
  addDoc,
  collection,
  getDoc,
  getDocs,
  query,
  where,
} from "firebase/firestore";
import { db } from "../../config/firebase";
import { auth } from "../../config/firebase";
import { useAuthState } from "react-firebase-hooks/auth";
import { useNavigate } from "react-router-dom";


interface Props {
  post: IPost;
  title: string;
}

function Posts(props: Props) {
  const { post, title } = props;

  const [user] = useAuthState(auth);

  const [likeAmount, setLikeAmount] = useState<number | null>();

  const likesRef = collection(db, "likes");

  const likesDoc = query(likesRef, where("postId", "==", post.id));

  const getLikes = async () => {
    const data = await getDocs(likesDoc);
    //console.log(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
    setLikeAmount(data.docs.length);
  };

  const addLike = async () => {
    await addDoc(likesRef, { userId: user?.uid, postId: post.id });
  };

  useEffect(() => {
    getLikes();
  }, []);

  //navigate('/');

  return (
    <div>
      {/* <h1>{post.id} {title}</h1>
      <p>{post.userId}</p> */}
      <div className="title">
        <h1>@{post.username}</h1>
        <button onClick={addLike}>&#128077;</button>
        {likeAmount && <p>Likes :  {likeAmount}</p>}
      </div>

      <div className="body">
        <p>{post.title}</p>
      </div>

      <div className="footer">
        <p>{post.description}</p>
      </div>
    </div>
  );
}

export default Posts;
